#ifndef GLOBAL_H
#define GLOBAL_H

#include <stdio.h>

#define FIFO_NAME "/tmp/rwfifo"
#define BUFFER_SIZE BUFSIZ
#define QUIT_CMD "quit"

#endif //GLOBAL_H

