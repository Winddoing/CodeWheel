#ifndef CLICKME_H
#define CLICKME_H

#include <QWidget>

namespace Ui {
    class ClickMe;
}

class ClickMe : public QWidget
{
    Q_OBJECT

public:
    explicit ClickMe(QWidget *parent = 0);
    ~ClickMe();
private:
    Ui::ClickMe *ui;
    int timerId;//QObject定时器ID
    QPixmap map;
    QRect frameArea;
private:
    void setRect();
protected:
    void timerEvent(QTimerEvent *e);//定时器事件处理函数
    void paintEvent(QPaintEvent *);//绘制事件处理函数
    void mousePressEvent(QMouseEvent *e);
private slots:
    void on_startBtn_clicked();

};

#endif // CLICKME_H
