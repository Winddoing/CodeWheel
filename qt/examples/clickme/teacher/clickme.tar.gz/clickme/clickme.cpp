#include "clickme.h"
#include "ui_clickme.h"

#include <time.h>

#include <QMouseEvent>
#include <QPainter> //

#include <QDebug>
//qDebug()      调试信息，主要用于在开发队段的调试用途
//qWarning()    警告信息，主要用于程序运阶段的输出
//qFatal()      致命错误，程序一但执行到此行，立即中止运行
//使用方法与printf,

ClickMe::ClickMe(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ClickMe)
{
    srand(time(0));
    ui->setupUi(this);
    //QWidget::sizeHint();返回当前窗口的建议尺寸
    setFixedSize(sizeHint());
    //当文件名以:开始，表示其为一个资源文件
    map.load(":/icons/clickme.png");
}
ClickMe::~ClickMe()
{
    delete ui;
}
void ClickMe::paintEvent(QPaintEvent *e)
{
    //1.仅允许在painterEvent事件处理函数中对窗口进行绘制
    //2.不允许对其它子窗口进行绘制
    QPainter painter(this);    //参数用于指定绘制对象
    //3.在这个对象析构时才向绘制对象绘制内容
    //计算绘制的区域

    painter.drawPixmap(frameArea, map);

    return QWidget::paintEvent(e);
}
void ClickMe::setRect()
{
    frameArea.setX(rand() % (ui->frame->width() -
                             map.width())
                   + ui->frame->geometry().x());
    frameArea.setY(rand() % (ui->frame->height() -
                             map.height())
                   + ui->frame->geometry().y());
    frameArea.setSize(map.size());
}
void ClickMe::mousePressEvent(QMouseEvent *e)
{
    //如果不是左键，或计时器指示为0秒时
    if(e->button() != Qt::LeftButton ||
       ui->secondLcdNumber->intValue() == 0)
        return QWidget::mousePressEvent(e);
    //如果点在显示的区域之内
    if(frameArea.contains(e->pos()))
    {
        //次数加一
        ui->timesLcdnumber->display(
            ui->timesLcdnumber->intValue() + 1);
        //取得下一次要显示的坐标
        setRect();
        //更新窗口上的显示
        update();
    }
    return QWidget::mousePressEvent(e);
}
void ClickMe::timerEvent(QTimerEvent *e)
{
    if(e->timerId() != timerId)
        return QWidget::timerEvent(e);
    int sec = ui->secondLcdNumber->intValue() - 1;

    ui->secondLcdNumber->display(sec);
    if(0 == sec)
    {
        killTimer(timerId);
        ui->startBtn->setEnabled(true);
    }
    return QWidget::timerEvent(e);
}

void ClickMe::on_startBtn_clicked()
{
    ui->timesLcdnumber->display(0);
    ui->startBtn->setEnabled(false);
    ui->secondLcdNumber->display(30);

    setRect();
    update();
    timerId = startTimer(1000);
}
